 module.exports = {
  prefix: "*"
}